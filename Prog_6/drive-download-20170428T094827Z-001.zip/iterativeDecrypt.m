function decrypt = iterativeDecrypt( cryptedChunkStream,key,funType )
shifts=flip((0:7));
for j=1:8
    binKey=dec2bin(key,8);
    currKey=circshift(binKey,shifts(j));
    currKey=bin2dec(currKey);
    decryptedChunkStream=zeros(size(cryptedChunkStream));
    for i=1:size(cryptedChunkStream,2)
        tmp=encryptFun(cryptedChunkStream(1:end/2,i),currKey,funType);
        decryptedChunkStream(1:end/2,i)=bitxor(cryptedChunkStream(end/2+1:end,i),tmp,'uint8');
        decryptedChunkStream(end/2+1:end,i)=cryptedChunkStream(1:end/2,i);
    end
    cryptedChunkStream=decryptedChunkStream;
end
    decrypt=cryptedChunkStream;
end


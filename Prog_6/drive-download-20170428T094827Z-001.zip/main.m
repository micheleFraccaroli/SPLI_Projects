close all;
clear all;
clc;

% Chunk 16 bytes
fileName='test_image.jpg';
[imageName,format] = strtok(fileName, '.');
format=format(2:end);
lengthChunk=16;
lengthKey=8;
key=17;
funType='xor';
% charKey=dec2bin(key,8);

fileIDImage=fopen(fileName);
bytesStream=fread(fileIDImage,'uint8');
fclose(fileIDImage);
nChunk=floor(length(bytesStream)/lengthChunk);
chunkStream=reshape(bytesStream(1:nChunk*lengthChunk),[lengthChunk nChunk]);
% bitsStream=dec2bin(bytesStream);
remainingBytes=length(bytesStream)-nChunk*lengthChunk;
if remainingBytes > 0
    paddingBytes=zeros(1,lengthChunk-remainingBytes);
    chunkStream=[chunkStream zeros(lengthChunk,2)];
    chunkStream(:,end-1)=[bytesStream(end-remainingBytes+1:end); paddingBytes'];
    chunkStream(end,end)=lengthChunk-remainingBytes;
else
    chunkStream=([chunkStream zeros(lengthChunk,1)]);
end

cryptedChunkStream=iterativeCrypt(chunkStream,key,funType);

%% Decrypt
fprintf('\n****************Decrypting Brute Force********************');

tic;

fprintf('\nTrying key value: %d',key);
decryptedChunkStream=iterativeDecrypt(cryptedChunkStream,key,funType);

decryptedBytesStream=reshape(decryptedChunkStream(:,1:end-2),[size(decryptedChunkStream(:,1:end-2),2)*lengthChunk 1]);
nPad=decryptedChunkStream(end,end);
decryptedBytesStream=[decryptedBytesStream ; decryptedChunkStream(1:end-nPad,end-1)];
decryptFileName=strcat('decrypt_image.',format);
fileIDDecryptImage=fopen(decryptFileName,'w');
fwrite(fileIDDecryptImage,decryptedBytesStream);
fclose(fileIDDecryptImage);
try
    RGB=imread(decryptFileName);
    timeElapsed=toc;
    fprintf(' -------> DECRYPTED');
    fprintf('\n****************End Brute Force***************************');
    fprintf('\n\n\n');
    fprintf('\nCorrect key value find is %d',key);
    fprintf('\nTime spent for decrypt the image: %.3f s',timeElapsed);
    fprintf('\n********************FINISH********************************\n')
    image(RGB)
catch ME
    fprintf(' -------> Decrypt failed\n');
end

